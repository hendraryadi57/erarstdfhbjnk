using UiPath.CodedWorkflows;

namespace btpns_autodeploy
{
    public class CodedWorkflow : CodedWorkflowBase
    {
        public CodedWorkflow()
        {
            _ = new System.Type[]{};
        }
    }
}